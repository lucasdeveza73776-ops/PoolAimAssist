package com.example.poolaimassist

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "Pool Aim Assist\n\nAssistente visual flutuante para estudo de trajetórias. Posicione a linha manualmente sobre a mesa."
            textSize = 19f
        })
        layout.addView(Button(this).apply {
            text = "Autorizar sobreposição"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startOverlay()
            }
        })
        layout.addView(Button(this).apply {
            text = "Abrir linhas sobre o jogo"
            setOnClickListener {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this@MainActivity)) startOverlay()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        layout.addView(TextView(this).apply {
            text = "\nComo usar: abra o overlay, toque no ponto da bola branca e arraste na direção desejada. Ajuste a força no controle inferior. Toque em Fechar para sair.\n\nLimitação desta versão: ela não reconhece automaticamente as bolas nem lê o estado do jogo; as posições e a direção são indicadas manualmente."
            textSize = 14f
        })
        setContentView(layout)
    }

    private fun startOverlay() {
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
        finish()
    }
}
