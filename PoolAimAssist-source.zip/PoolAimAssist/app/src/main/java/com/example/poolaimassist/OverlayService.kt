package com.example.poolaimassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var guide: GuideView
    private var guideParams: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("pool_overlay", "Pool overlay", android.app.NotificationManager.IMPORTANCE_LOW)
            getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
            val notification = Notification.Builder(this, "pool_overlay")
                .setContentTitle("Pool Aim Assist ativo")
                .setContentText("Linhas de referência sobre a tela")
                .setSmallIcon(android.R.drawable.ic_menu_compass).build()
            startForeground(7, notification)
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        guide = GuideView(this)
        val visualParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        guideParams = visualParams
        wm.addView(guide, visualParams)
        createControlPanel()
    }

    private fun createControlPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 10, 10, 10)
            setBackgroundColor(0xDD202020.toInt())
        }
        fun control(label: String, action: () -> Unit) {
            p.addView(TextView(this).apply {
                text = label; textSize = 13f; setTextColor(Color.WHITE)
                setPadding(12, 10, 12, 10); setOnClickListener { action() }
            })
        }
        control("Ângulo −") { guide.changeAngle(-5f) }
        control("Ângulo +") { guide.changeAngle(5f) }
        control("Força −") { guide.changeForce(-.05f) }
        control("Força +") { guide.changeForce(.05f) }
        control("Mover início") { guide.moveStart() }
        control("FECHAR") { stopSelf() }
        panel = p
        val pp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 140 }
        panelParams = pp
        wm.addView(p, pp)
    }

    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { guideParams?.let { wm.removeView(guide) } } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private class GuideView(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var angle = 0f
        private var force = .55f
        private var startX = .50f
        private var startY = .52f
        fun changeAngle(v: Float) { angle = (angle + v).coerceIn(-180f, 180f); invalidate() }
        fun changeForce(v: Float) { force = (force + v).coerceIn(.05f, 1f); invalidate() }
        fun moveStart() { startX = (startX + .06f).let { if (it > .85f) .15f else it }; invalidate() }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            if (width == 0 || height == 0) return
            val left = width * .08f; val right = width * .92f
            val top = height * .17f; val bottom = height * .78f
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x88FFFFFF.toInt()
            c.drawRoundRect(left, top, right, bottom, 22f, 22f, p)
            val pockets = listOf(left to top, width/2f to top, right to top, left to bottom, width/2f to bottom, right to bottom)
            p.style = Paint.Style.FILL; p.color = 0xDD111111.toInt()
            pockets.forEach { c.drawCircle(it.first, it.second, 12f, p) }
            val sx = width * startX; val sy = height * startY
            val rad = Math.toRadians(angle.toDouble())
            val ux = cos(rad).toFloat(); val uy = sin(rad).toFloat()
            val reach = width * (.16f + force * .62f)
            val ex = sx + ux * reach; val ey = sy + uy * reach
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = 0xFF40E0D0.toInt()
            c.drawLine(sx, sy, ex, ey, p)
            val hitX = sx + ux * reach * .58f; val hitY = sy + uy * reach * .58f
            p.strokeWidth = 3f; p.color = 0xFFFFC107.toInt()
            c.drawLine(hitX, hitY, ex, ey, p)
            p.strokeWidth = 2f; p.color = 0xFFFF5252.toInt()
            pockets.forEach { pocket -> c.drawPath(Path().apply { moveTo(hitX, hitY); lineTo(pocket.first, pocket.second) }, p) }
            p.style = Paint.Style.FILL; p.color = Color.WHITE; c.drawCircle(sx, sy, 8f, p)
            p.color = 0xFFFFC107.toInt(); c.drawCircle(hitX, hitY, 7f, p)
            p.color = Color.WHITE; p.textSize = 22f
            c.drawText("REFERÊNCIA • ÂNGULO ${angle.toInt()}° • FORÇA ${(force*100).toInt()}%", width*.08f, height*.12f, p)
        }
    }
}
