# Pool Aim Assist — protótipo Android

Projeto-fonte inicial de um overlay visual flutuante para Android.

## Abrir no Android Studio
1. Extraia o ZIP e abra a pasta `PoolAimAssist` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Execute em um celular Android (API 23 ou superior).
4. Autorize **sobrepor a outros apps** e toque em **Abrir linhas sobre o jogo**.

## Controles
O desenho de referência não captura toques do jogo: a camada gráfica é transparente a toques para que você continue jogando. O pequeno painel flutuante ajusta ângulo, força aproximada e posição inicial.

## Limitações
Esta versão é um protótipo manual. Ela não identifica automaticamente as bolas ou as caçapas reais, não calcula colisões físicas com precisão e não lê a força do taco. As linhas são referências geométricas genéricas e precisam ser alinhadas visualmente à mesa. Um sistema automático exigiria captura/análise de imagem e calibração específica, que não estão incluídas neste projeto. A compatibilidade de overlays varia conforme o Android e o fabricante.
