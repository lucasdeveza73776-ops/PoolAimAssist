# Pool Aim Assist (protótipo)

Aplicativo Android de sobreposição com linhas de referência desenhadas manualmente. Compatível em princípio com Android 6.0+; pensado para teste em Android 12.

## Limitações
Esta versão NÃO detecta automaticamente bolas, caçapas, ângulo ou força dentro do 8 Ball Pool. As linhas são referências manuais e não garantem a trajetória física real. Não automatiza toques nem joga pelo usuário.

## Compilação
O workflow em `.github/workflows/android.yml` gera um APK de depuração quando o conteúdo deste projeto está na raiz do repositório GitHub.
